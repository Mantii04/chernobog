/*
 *  Interactive disassembler (IDA).
 *  Intel 80196 module
 *
 */

#ifndef _I196_HPP
#define _I196_HPP

#include "../idaidp.hpp"
#include "ins.hpp"
#include <segregs.hpp>

//------------------------------------------------------------------------
// customization of cmd structure:

#define o_indirect      o_idpspec0      // [addr]
#define o_indirect_inc  o_idpspec1      // [addr]+
#define o_indexed       o_idpspec2      // addr[value]
#define o_bit           o_idpspec3

//-------------------------------------------------------------------------
inline bool is_ext_insn(const insn_t &insn)
{
  switch ( insn.itype )
  {
    case I196_ebmovi:      // Extended interruptable block move
    case I196_ebr:         // Extended branch indirect
    case I196_ecall:       // Extended call
    case I196_ejmp:        // Extended jump
    case I196_eld:         // Extended load word
    case I196_eldb:        // Extended load byte
    case I196_est:         // Extended store word
    case I196_estb:        // Extended store byte
      return true;
  }
  return false;
}

//------------------------------------------------------------------------

enum i196_registers { rVcs, rVds, WSR, WSR1 };
enum i196_proctype_t
{
  PT_NONE,
  PT_80196,
  PT_80196NP,      // instructions for extended addressing
  PT_8096,     // 8[037]9[567] - subset of 80196
  PT_8061,
  PT_8065
};

typedef struct
{
  uchar addr;
  const char *name;
  const char *cmt;
} predefined_t;

//------------------------------------------------------------------------
void idaapi out_insn(outctx_t &ctx, bool use_alternative_mnem);
void idaapi i196_header(outctx_t &ctx);
void idaapi i196_footer(outctx_t &ctx);

void idaapi i196_segend(outctx_t &ctx, ea_t seg_ea);

//------------------------------------------------------------------------
struct i196_t : public procmod_t
{
  int flow = false;
  i196_proctype_t proctype = PT_NONE;
  i196_proctype_t proctypes[6] =
  {
    PT_80196,
    PT_80196NP,
    PT_8096,
    PT_8061,
    PT_8065,
    PT_NONE,
  };
  int last_valid_procidx = qnumber(proctypes) - 1;

  inline uint32 truncate(ea_t x)
  {
    return x & (is_80196NP() ? 0xFFFFF : 0xFFFF);
  }

  inline bool is_8061() const { return proctype == PT_8061; }
  inline bool is_8065() const { return proctype == PT_8065; }
  inline bool is_8x6x() const { return proctype == PT_8061 || proctype == PT_8065; }
  inline bool is_8096() const { return proctype == PT_8096; }
  inline bool is_80196() const { return proctype == PT_80196 || proctype == PT_80196NP; }
  inline bool is_80196NP() const { return proctype == PT_80196NP; }

  virtual ssize_t idaapi on_event(ssize_t msgid, va_list va) override;

  ea_t map(ea_t iea, ea_t v) const;
  void aop(insn_t &insn, uint code, op_t &op);
  int ld_st(insn_t &insn, ushort itype, char dtype, bool indirect, op_t &reg, op_t &mem);
  int ana(insn_t *_insn);

  bool is_sane_insn(const insn_t &insn) const;

  void handle_operand(const insn_t &insn, const op_t &x, int isload);
  int emu(const insn_t &insn);

  void i196_segstart(outctx_t &ctx, ea_t seg_ea) const;
};

#endif
