/*
        Interactive disassembler (IDA).
        Copyright (c) 2005-2026 Hex-Rays SA <support@hex-rays.com>
        ALL RIGHTS RESERVED.

        Merge functionality.

*/

#include "h8.hpp"
#include <merge.hpp>
#include "../mergecmn.cpp"

DEFINE_SIMPLE_PROCMOD_HANDLER(idbattr_device_name)
